package day43_Abstraction.shapeTask;

public class ShapeObjects {

    public static void main(String[] args) {

        Rectangle rec = new Rectangle(1.5, 2.5);

        Square square = new Square(2.6);

        Circle circle = new Circle(3.5);

        System.out.println(rec);
        System.out.println(square);
        System.out.println(circle);







    }

}
