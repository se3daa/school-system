package week3;

public class IfAndElse {
    public static void main(String[] args) {
        int score = 55;

        if(score >= 60){
            System.out.println("Passed");
        }else{
            System.out.println("Failed");

        }

    }

}
/*
the if...else stmt checks a condition
if it resolves to true the first code block is executed
if the condition resolves to false, the second code block is run instead

if(Condition){
Stmts}else{stmts}
 */