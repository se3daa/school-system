package week3;

public class IfStmt_SingleIf {
    public static void main(String[] args) {
        int score = 75;
        if(score >= 60) {
            System.out.println("Congratulations on passing your exam!");

        }
    }
}
/*
evaluates a condition
If the condition evaluates to true, any stmts in the subsequent code block are executed.
 only use for one condition, one output

      if(Condition){ Statements}
 */