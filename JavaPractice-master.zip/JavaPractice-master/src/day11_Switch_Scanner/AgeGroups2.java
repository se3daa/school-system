package day11_Switch_Scanner;

public class AgeGroups2 {
    public static void main(String[] args) {
        int ageGroup = 2;
        String result = "";






    }
}
