package day11_Switch_Scanner;

public class CappuccinoBuyer1 {
    public static void main(String[] args) {
        String size = "tall";






    }
}
