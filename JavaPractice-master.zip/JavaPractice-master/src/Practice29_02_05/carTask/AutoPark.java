package Practice29_02_05.carTask;

public interface AutoPark {
    boolean hasAutoPark = true;
    void autoPark();


}
