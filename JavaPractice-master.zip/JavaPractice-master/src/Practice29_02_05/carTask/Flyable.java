package Practice29_02_05.carTask;

public interface Flyable {
    boolean canFly = true;
    void fly();
}
