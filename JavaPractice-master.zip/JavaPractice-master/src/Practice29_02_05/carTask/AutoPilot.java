package Practice29_02_05.carTask;

public interface AutoPilot {
    boolean hasAutoPilot = true;
    void selfDrive();
}
