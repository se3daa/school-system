package Practice29_02_05.browserTask;

public class FireFoxDriver extends RemoteWebDriver{
    public FireFoxDriver() {
        super("FireFox");
    }
}
