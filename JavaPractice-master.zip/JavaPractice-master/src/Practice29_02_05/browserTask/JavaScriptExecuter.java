package Practice29_02_05.browserTask;

public interface JavaScriptExecuter {
    void executeScript(String script);
}
