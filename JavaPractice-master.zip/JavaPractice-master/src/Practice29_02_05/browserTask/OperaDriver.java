package Practice29_02_05.browserTask;

public class OperaDriver extends RemoteWebDriver{
    public OperaDriver() {
        super("Opera");
    }
}
