package Practice29_02_05.browserTask;

public class ChromeDriver extends RemoteWebDriver{
    public ChromeDriver() {
        super("Chrome");
    }

}
