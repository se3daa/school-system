package Practice29_02_05.browserTask;

public interface SearchContext {
    void findElement(String locator);
    void findElements(String locator);
}
