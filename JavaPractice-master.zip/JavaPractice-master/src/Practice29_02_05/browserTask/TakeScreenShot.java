package Practice29_02_05.browserTask;

public interface TakeScreenShot {
    void takeScreenShot();
}
