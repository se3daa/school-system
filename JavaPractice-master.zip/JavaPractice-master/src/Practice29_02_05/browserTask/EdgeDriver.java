package Practice29_02_05.browserTask;

public class EdgeDriver extends RemoteWebDriver{
    public EdgeDriver() {
        super("Edge");
    }
}
