package Practice29_02_05.browserTask;

public class SafariDriver extends RemoteWebDriver{
    public SafariDriver() {
        super("Safari");
    }
}
