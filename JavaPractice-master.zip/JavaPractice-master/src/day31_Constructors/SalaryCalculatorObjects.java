package day31_Constructors;

public class SalaryCalculatorObjects {
    public static void main(String[] args) {

        SalaryCalculator salary1 = new SalaryCalculator(52.50, 9.76,25.65,40);

        System.out.println(salary1);







    }
}
