package day31_Constructors;



public class ItemObjects {
    public static void main(String[] args) {


        Item item1 = new Item("Apple", 1.99, 5);
        System.out.println(item1);



    }
}
