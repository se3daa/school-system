package day31_Constructors;

public class AddressObjects {
    public static void main(String[] args) {

        Address address1 = new Address("7925", "Jones Branch Dr", "Mclean", "VA", 22012);
        System.out.println(address1);







    }
}
