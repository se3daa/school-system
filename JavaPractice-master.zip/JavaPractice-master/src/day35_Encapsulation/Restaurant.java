package day35_Encapsulation;

public class Restaurant {
}
/*
5. Restaurant Task:
    re-do the Restaurant task by making all the fields private in each custom classes

    Encapsulate all the field
        (salary cannot be set to negative)
        (employeeId cannot be set to negative or zero)

    Avoid any duplicated code fragments in each class


 */