package day35_Encapsulation;

public class CredentialsObject {
    public static void main(String[] args) {

        Credentials cre1 = new Credentials("jhfad", "fhgs154sad");

        System.out.println(cre1);





    }
}
