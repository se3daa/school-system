package day35_Encapsulation;

public class ItemObjects {
    public static void main(String[] args) {

        Item item1 = new Item("toilet paper!", 2,4);

        System.out.println(item1);


    }
}
