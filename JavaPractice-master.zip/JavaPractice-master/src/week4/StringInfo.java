package week4;

public class StringInfo {
}
