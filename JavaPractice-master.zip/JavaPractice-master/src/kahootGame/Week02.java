package kahootGame;

public class Week02 {
    public static void main(String[] args) {
        int a = 10, b = 2, result = -1+a*b/a*b*b-2;
        System.out.println(result);
        boolean x = false != true;
        System.out.println(x);
    }
}
