package day23_CustomMethods_Void;

public class Task7_AreaOfSquare {

    // 7. create a method that can calculate the area of a square

    public static void main(String[] args) {

        areaOfSquare(3);

    }


    public static void areaOfSquare(int width){

        int areaOfSquare = width*4;

        System.out.println("areaOfSquare = " + areaOfSquare);

    }



}
