package day36_Inheritance.cryptoTokenTask;

public class Ethereum extends CryptoToken{
}
