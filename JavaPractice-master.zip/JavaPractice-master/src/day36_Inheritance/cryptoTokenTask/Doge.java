package day36_Inheritance.cryptoTokenTask;

public class Doge extends CryptoToken{
}
