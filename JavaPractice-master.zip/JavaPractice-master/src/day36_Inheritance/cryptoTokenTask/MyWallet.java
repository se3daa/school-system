package day36_Inheritance.cryptoTokenTask;

public class MyWallet {
}
/*
3. create a class named MyWallet

		create one object of each CryptoToken

		calculate the total Asset
 */