package day36_Inheritance.cryptoTokenTask;

public class Cardano extends CryptoToken{
}
