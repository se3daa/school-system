package day36_Inheritance.cryptoTokenTask;

public class Bitcoin extends CryptoToken{
}
