package day36_Inheritance.cryptoTokenTask;

public class XRP extends CryptoToken{
}
