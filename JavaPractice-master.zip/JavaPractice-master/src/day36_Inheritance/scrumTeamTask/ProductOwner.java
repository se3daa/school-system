package day36_Inheritance.scrumTeamTask;

public class ProductOwner extends Employee{
    public ProductOwner(String name, int age, char gender, int id, String jobTitle, double salary) {
        super(name, age, gender, id, jobTitle, salary);
    }
}
/*
6. Create a sub class of EMployee named ProductOwner:

			Add any extra variable or method that ProductOwner object need to have
 */