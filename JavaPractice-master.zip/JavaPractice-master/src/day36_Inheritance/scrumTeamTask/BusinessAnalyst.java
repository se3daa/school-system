package day36_Inheritance.scrumTeamTask;

public class BusinessAnalyst extends Employee {

    public BusinessAnalyst(String name, int age, char gender, int id, String jobTitle, double salary) {
        super(name, age, gender, id, jobTitle, salary);
    }
}
/*
5. Create a sub class of EMployee named BusinessAnalyst:

			Add any extra variable or method that BusinessAnalyst object need to have
 */