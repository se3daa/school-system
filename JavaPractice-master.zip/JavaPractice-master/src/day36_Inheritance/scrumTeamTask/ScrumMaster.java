package day36_Inheritance.scrumTeamTask;

public class ScrumMaster {
}
/*
7. Create a sub class of EMployee named ScrumMaster:

			Add any extra variable or method that ScrumMaster object need to have

 */