package day36_Inheritance.scrumTeamTask;

public class Tester extends Employee{
    public Tester(String name, int age, char gender, int id, String jobTitle, double salary) {
        super(name, age, gender, id, jobTitle, salary);
    }
}
/*
3. Create a sub class of Employee named Tester:

			Add any extra variable or method that Tester object need to have

 */