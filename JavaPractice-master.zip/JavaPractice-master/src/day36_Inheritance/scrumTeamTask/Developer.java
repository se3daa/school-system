package day36_Inheritance.scrumTeamTask;

public class Developer extends Employee{
    public Developer(String name, int age, char gender, int id, String jobTitle, double salary) {
        super(name, age, gender, id, jobTitle, salary);
    }
}
/*
4. Create a sub class of EMployee named Developer:

			Add any extra variable or method that Developer object need to have

 */