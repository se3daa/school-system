package day36_Inheritance.sportsTask;

public class Baseball extends Sport{

    public void strike(){
        System.out.println(name+" is striked");
    }
    public void tagUp(){
        System.out.println(name+" is tagging up");
    }


}
