package day36_Inheritance.sportsTask;

public class Football extends Sport{
}
