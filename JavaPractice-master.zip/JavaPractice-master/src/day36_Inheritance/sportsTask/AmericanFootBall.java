package day36_Inheritance.sportsTask;

public class AmericanFootBall extends Sport{
}
