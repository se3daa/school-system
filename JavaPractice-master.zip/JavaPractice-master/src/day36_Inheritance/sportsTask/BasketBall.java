package day36_Inheritance.sportsTask;

public class BasketBall extends Sport{

    public void bounce(){
        System.out.println(name + " is bouncing");
    }


}
