package day36_Inheritance.employeeTask;

public class Driver extends Employee{

    public void drivering(){
        System.out.println(name+" is driving");
    }

}
/*
2.6 Create the sub class of Employee named Driver:
			variables:
				name, gender, age, id, jobTitle, salary

			Methods:
				setInfo()
				work()
				drivering()
				toString()
 */