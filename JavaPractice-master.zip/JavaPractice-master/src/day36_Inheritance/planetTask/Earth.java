package day36_Inheritance.planetTask;

public class Earth extends Planet{
}
