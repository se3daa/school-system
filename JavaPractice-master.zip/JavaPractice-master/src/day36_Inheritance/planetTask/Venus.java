package day36_Inheritance.planetTask;

public class Venus extends Planet{
}
