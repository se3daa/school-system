package day36_Inheritance.planetTask;

public class Moon extends Planet{
}
