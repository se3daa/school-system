package day36_Inheritance.planetTask;

public class Mercury extends Planet{
}
