package day38_Inheritance.browserTask;

public class Browser {

    public void openBrowser(){
        System.out.println("opening chrome browser");
    }

    public void closeBrowser(){
        System.out.println("closing chrome browser");
    }


}
