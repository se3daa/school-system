package day38_Inheritance.browserTask;

public class ChromeBrowser extends Browser{


}
