package day38_Inheritance.shapeTask;

public class MathShape {
    public static void main(String[] args) {

        Circle c1 = new Circle(4.5);

        Rectangle r1 = new Rectangle(2.5,3.5);

        Square s1 = new Square(1.5);

        System.out.println(c1);
        System.out.println(r1);
        System.out.println(s1);






    }
}
