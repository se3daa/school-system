package snacks;

public class MaximumNumber {
    public static void main(String[] args) {
        int n1 = 100,
                n2 = 100;
        if(n2 > n1){
            System.out.println(n2 + " is the maximum number");
        }
        if(n2 == n1){
            System.out.println(n2+ " and " + n1 + " both are equal");
        }




    }
}
/*
3. Write a program that can print the maximum number between two numbers, if both are equal then print Equal

            Ex:
                n1= 100, n2 = 200;

            output:
                200 is the maximum number
 */