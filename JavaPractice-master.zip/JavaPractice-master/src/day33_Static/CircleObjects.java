package day33_Static;

public class CircleObjects {
    public static void main(String[] args) {

        Circle circle1 = new Circle(2.5,3.5);

        System.out.println(circle1);


    }
}
