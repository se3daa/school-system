package day39_Recap.deviceTask;

public class MyDevices {
    public static void main(String[] args) {

        Iphone ip = new Iphone("Ip 13 Promax", 1200);

        SamSung samsung = new SamSung("ZFlip3", 1100);

        Laptop laptop = new Laptop("Microsoft", "Surface pro 7", 1349);

        TV tv = new TV("LG", "upstar", 800);

        System.out.println(ip);
        System.out.println(samsung);
        System.out.println(laptop);
        System.out.println(tv);

















    }
}
