package day39_Recap.deviceTask;

public class BlackBeery extends Phone{
    public BlackBeery( String model, double price) {
        super("Black Beery", model, price);
    }
}
