package day39_Recap.deviceTask;

public class Nokia extends Phone{
    public Nokia( String model, double price) {
        super("Nokia", model, price);
    }
}
